#include<stdio.h>
int main(){
int i;
for(i = 0;i < 30; i++){
printf("hello world");
}
return 0;
}
