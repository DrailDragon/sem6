#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/wait.h>
#define BUF_SIZE 80000

//01btech
//41mtech
//61phd
int main(int argc,char* argv[]){
	char path1[100],path2[100],in1[10],in2[10];
	strcpy(path1,"./database/BT/bt101.txt");
	strcpy(path2,"./database/CSE/cs699.txt");
	/*char* t1=strtok(in1,".");
	char* t2=strtok(in2,".");
	strcpy(path1,"./database/");
	strcat(path1,t1);
	strcat(path1,argv[1]);
	strcpy(path2,"./database/");
	strcat(path2,t2);
	strcat(path2,argv[2]);
	//strcpy(path1,"./database/BT/bt101.txt");*/
	/*open pipes*/
	char* t1,*t2;
	int pfd1[2],pfd2[2];
	if(pipe(pfd1)==-1){
	printf("Error opening pipe1\n");
	return -1;
	}
	if(pipe(pfd2)==-1){
	printf("Error opening pipe2\n");
	return -1;
	}
	/*****open file1********/
	int numRead,numWR,inFd1,inFd2;
	char buf1[BUF_SIZE],buf2[BUF_SIZE];
	/*********Open input file in readonly mode to read data*******************/
		inFd1=open(path1,O_RDONLY);
		if(inFd1==-1){
		printf("Error opening file %s\n",path1);
		return -1;
		}
		inFd2=open(path2,O_RDONLY);
		if(inFd2==-1){
		printf("Error opening file %s\n",path2);
		return -1;
		}
		/*********Read data from input file **********************/
		numRead=read(inFd1,buf1,BUF_SIZE);
		if(numRead<=0){
		printf("Error reading from file %s\n",path1);
		return -1;
		}
		numRead=read(inFd2,buf2,BUF_SIZE);
		if(numRead<=0){
		printf("Error reading from file %s\n",path2);
		return -1;
		}
		/****Close input file *************/
		if(close(inFd1)==-1){
		printf("Error closing file %s\n",path1);
		return -1;
		}
		if(close(inFd2)==-1){
		printf("Error closing file %s\n",path2);
		return -1;
		}
		
		/*****Write the buffer into the pipe***************/
		if(write(pfd1[1],buf1,strlen(buf1))<=0){
		printf("Error writing to the pipe1\n");
		return -1;
		}
		if(write(pfd2[1],buf2,strlen(buf2))<=0){
		printf("Error writing to the pipe2\n");
		return -1;
		}
		/******Close the write pipe-end of child ********/
		if(close(pfd1[1])==-1){
		printf("Error closing write-end of pipe1\n");
		return -1;
		}
		if(close(pfd2[1])==-1){
		printf("Error closing write-end of pipe2\n");
		return -1;
		}
		/****Read from pipes*******/
		numRead=read(pfd1[0],buf1,BUF_SIZE);
		if(numRead<=0){
		printf(" Error reading pipe1\n");
		return -1;
		}
		numRead=read(pfd2[0],buf2,BUF_SIZE);
		if(numRead<=0){
		printf(" Error reading pipe2\n");
		return -1;
		}
		/***open files to write on **/
	int outFd1,outFd2,outFd3,openFlag,filePerms;
	openFlag= O_CREAT | O_WRONLY |O_APPEND ;
	filePerms= S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH;
	outFd1 = open("btech.txt",openFlag,filePerms);
	outFd2 = open("mtech.txt",openFlag,filePerms);
	outFd3 = open("phd.txt",openFlag,filePerms);
		if(outFd1==-1){
		printf("Error opening file btech.txt\n");
		return -1;
		}
		if(outFd2==-1){
		printf("Error opening file mtech.txt\n");
		return -1;
		}
		if(outFd3==-1){
		printf("Error opening file phd.txt\n");
		return -1;
		}
		char s[]=",\n";
		int tln;
		char t3[100];
		
		do{
		t1=strtok(buf1,s);
		if(t1==NULL) break;
		strcpy(t3,t1);
		strcat(t3,",");
		t2=strtok(NULL,s);
		if(t2==NULL) break;
		strcat(t3,t2);
		strcat(t3,"\n");
		tln=strlen(t3);
		if(t1[2]=='0' && t1[3]=='1'){
			
			numWR=write(outFd1,t3,tln);
			if(numWR<=0){
			printf("Err WR1\n");
			return -1;
			}
		}else if(t1[2]=='4' && t1[3]=='1'){
			
			numWR=write(outFd2,t3,tln);
			if(numWR<=0){
			printf("Err WR2\n");
			return -1;
			}
		}else if(t1[2]=='6' && t1[3]=='1'){
			numWR=write(outFd3,t3,tln);
			if(numWR<=0){
			printf("Err WR3\n");
			return -1;
			}
		}
		strtok(NULL,s);
		}while(t1!=NULL);

		do{
		t1=strtok(buf2,s);
		if(t1==NULL) break;
		strcpy(t3,t1);
		strcat(t3,",");
		t2=strtok(NULL,s);
		if(t2==NULL) break;
		strcat(t3,t2);
		strcat(t3,"\n");
		tln=strlen(t3);
		if(t1[2]=='0' && t1[3]=='1'){
			numWR=write(outFd1,t3,tln);
			if(numWR<=0){
			printf("Err WR1\n");
			return -1;
			}
		}else if(t1[2]=='4' && t1[3]=='1'){
			numWR=write(outFd2,t3,tln);
			if(numWR<=0){
			printf("Err WR2\n");
			return -1;
			}
		}else if(t1[2]=='6' && t1[3]=='1'){
			numWR=write(outFd3,t3,tln);
			if(numWR<=0){
			printf("Err WR3\n");
			return -1;
			}
		}
			strtok(NULL,s);
		}while(t1!=NULL);


		if(close(pfd1[0])==-1){
		printf("Error closing pipe1 read end\n");
		return -1;
		}
		if(close(pfd2[0])==-1){
		printf("Error closing pipe2 read end\n");
		return -1;
		}
		if(close(outFd1)==-1){
		printf("Error closing file btech.txt\n");
		return -1;
		}
		if(close(outFd2)==-1){
		printf("Error closing file mtech.txt\n");
		return -1;
		}
		if(close(outFd3)==-1){
		printf("Error closing file phd.txt\n");
		return -1;
		}
		return 0;
}
