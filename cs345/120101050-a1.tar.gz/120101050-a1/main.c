#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<error.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<stdio.h>
struct student
{
    char roll[10];
    char courses[20][30];
    int course_cnt;
    char c_code[20][10];
};
struct student* st=NULL;
int count=0,siz=500;
/*get course name*/

int search_st(char* roll)
{
    if(!roll) return -1;
    int i;
    for(i=0; i<siz; i++)
    {
	if(st==NULL)
		break;
        if(strcmp(st[i].roll,roll)==0)
        {
            return i;
        }
    }
    return -1;
}
char* search_name(char coursecd[])
{
    FILE* fp=fopen("/home/pintukumar/cs345/database/index.txt","r");
    if(fp==NULL)
    {
        printf("error opening index.txt\n");
        return NULL;
    }
    char read;
    char *line = NULL;
    size_t len = 0;
    while ((read = getline(&line,&len, fp)) != -1)
    {
        const char s[] =",";
        char* token = strtok(line,s);
        if(strcmp(token,coursecd)==0)
        {

            token=strtok(NULL,s);
            fclose(fp);
            return token;
        }

    }
	if(fp)
    fclose(fp);

    return NULL;
}

int read_dir(char *pth)
{
    char path[1000];
    strcpy(path,pth);
    DIR *dp;
    struct dirent *files;
    /*structure for storing inode numbers and files in dir
    struct dirent
    {
        ino_t d_ino;
        char d_name[NAME_MAX+1]
    }
    */
    if((dp=opendir(path))==NULL)
        perror("dir\n");
    char newp[1000];
    struct stat buf;
    while((files=readdir(dp))!=NULL)
    {
        if(!strcmp(files->d_name,".") || !strcmp(files->d_name,".."))
            continue;
        strcpy(newp,path);
        strcat(newp,"/");
        strcat(newp,files->d_name);
        //printf("%s\n",newp);
        FILE* f1= fopen(newp,"r");

        /*extract course number*/
        const char s1[] =".";
        char* token1 = strtok(files->d_name,s1);/*token1 contains course code*/

        //printf("%s\n",token1);
        char read;
        char *line = NULL;
        size_t len = 0;
        while ((read = getline(&line,&len, f1)) != -1)
        {
            const char s[] =",";
            char* token = strtok(line,s);
            //printf("%s\n",token);
            if(st==NULL)
            {
                st=(struct student*)malloc(siz*sizeof(struct student));
                if(st==NULL)
                {
                    printf("error malloc\n");
                    return -1;
                }
		int i;
		for(i=0;i<siz;i++){
		st[i].course_cnt=0;
		}
                /*st[count].courses[st[count].course_cnt]=(char*)malloc(20*sizeof(char));
                st[count].c_code[st[count].course_cnt]=(char*)malloc(10*sizeof(char));*/
                strcpy(st[count].roll,token);
               // printf("%s\n",st[count].roll);
            }
            else if(count>=siz)
            {
                
                st=(struct student*)realloc(st,(siz+100)*sizeof(struct student));
                if(st==NULL)
                {
                    printf("error realloc\n");
                    return -1;
                }
		int i;
		for(i=siz;i<siz+100;i++){
		st[i].course_cnt=0;
		}
		siz+=100;
                /*  st[count].courses[st[count].course_cnt]=(char*)malloc(20*sizeof(char));
                  st[count].c_code[st[count].course_cnt]=(char*)malloc(10*sizeof(char));*/
                int num = search_st(token);
                if(num==-1)
                    strcpy(st[count].roll,token);
                    strcpy(st[count].c_code[st[count].course_cnt],token1);
                    strcpy(st[count].courses[st[count].course_cnt],search_name(token1));
                
            }
            else
            {
                int num = search_st(token);
                if(num==-1)
                    strcpy(st[count].roll,token);
                strcpy(st[count].c_code[st[count].course_cnt],token1);
                strcpy(st[count].courses[st[count].course_cnt],search_name(token1));
            }
            if(st[count].course_cnt>20)
            {
                printf("coursecount exceeded");
                return 0;
            }
            st[count].course_cnt++;
            count++;
	if(line) line=NULL;
        }
        fclose(f1);
        //stat function return a structure of information about the file
        if(stat(newp,&buf)==-1)
            perror("stat");
        if(S_ISDIR(buf.st_mode))// if directory, then add a "/" to current path
        {

            strcat(path,"/");
            strcat(path,files->d_name);
            read_dir(path);
            strcpy(path,pth);
        }
    }
}

bool flush_todisk()
{
    int i;
    FILE* f2;
    for(i=0; i<count; i++)
    {
        char roll[3] = "";
        roll[0]=st[i].roll[4];
        roll[1]=st[i].roll[5];
        if(strcmp(roll,"01")==0)
        {
            f2=fopen("cse.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"02")==0)
        {
            f2=fopen("ece.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"03")==0)
        {
            f2=fopen("me.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"04")==0)
        {
            f2=fopen("ce.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"05")==0)
        {
            f2=fopen("dd.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"06")==0)
        {
            f2=fopen("bt.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"07")==0)
        {
            f2=fopen("cl.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"08")==0)
        {
            f2=fopen("eee.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"21")==0)
        {
            f2=fopen("ep.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"22")==0)
        {
            f2=fopen("ct.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"23")==0)
        {
            f2=fopen("mc.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else if(strcmp(roll,"41")==0)
        {
            f2=fopen("hs.txt","w+");
            int j=0;
            fprintf(f2,"%s\t%s\t\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
            for(j=1; j<st[i].course_cnt; j++)
            {
                fprintf(f2,"\t\t%s\t\t%s\n",st[i].c_code[j],st[i].courses[j]);
            }
            fclose(f2);
        }
        else
        {
            printf("Invalid roll extracted\n");
            /*invalid*/
            return false;
        }

    }
    return true;
}

int main(int argc,char *argv[])
{
    //char pathname[]="/home/pintukumar/cs345/database";
    read_dir(argv[1]);
    flush_todisk();
    st=NULL;
    return 0;
}

