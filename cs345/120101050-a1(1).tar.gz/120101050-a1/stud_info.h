#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<error.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<stdio.h>

#ifndef STD_INFO_H
#define STD_INFO_H
struct student
{
    char roll[10];
    char courses[20][40];
    int course_cnt;
    char c_code[20][10];
};
struct student* st=NULL;
int count=0,siz=500;

int search_st(char* roll)
{
    if(!roll) return -1;
    int i;
    for(i=0; i<siz; i++)
    {
        if(st==NULL)
            break;
        if(strcmp(st[i].roll,roll)==0)
        {
            return i;
        }
    }
    return -1;
}
bool load_stud_info(const char* filename){
FILE* fp=fopen(filename,"r");
char* line=NULL;
size_t len=0;
while(getline(&line,&len,fp)!=-1)
{
    const char s[]="\t";
    char* token=strtok(line,s);
    char* token1=strtok(NULL,s);//course_code
    char* token2=strtok(NULL,s);//cource_name
    if(token==NULL || token1==NULL || token2 ==NULL)
        continue;
        if(st==NULL)
        {
           // printf("st malloc\n");
            st=(struct student*)malloc(siz*sizeof(struct student));
            if(st==NULL)
            {
                printf("error malloc\n");
                if(fp) fclose(fp);
                return -1;
            }
            int i;
            for(i=0; i<siz; i++)
            {
                st[i].course_cnt=0;
            }
            /*st[count].courses[st[count].course_cnt]=(char*)malloc(20*sizeof(char));
            st[count].c_code[st[count].course_cnt]=(char*)malloc(10*sizeof(char));*/
            strcpy(st[count].roll,token);
            strcpy(st[count].c_code[st[count].course_cnt],token1);
            strcpy(st[count].courses[st[count].course_cnt],token2);
            //printf("%s\t%s\t%s\n",st[count].roll,st[count].c_code[st[count].course_cnt],st[count].courses[st[count].course_cnt]);
            count++;
            // printf("%s\n",st[count].roll);
        }
        else if(count>=siz)
        {

            st=(struct student*)realloc(st,(siz+100)*sizeof(struct student));
            if(st==NULL)
            {
                printf("error realloc\n");
                if(fp) fclose(fp);
                return -1;
            }
            int i;
            for(i=siz; i<siz+100; i++)
            {
                st[i].course_cnt=0;
            }
            siz+=100;
            /*  st[count].courses[st[count].course_cnt]=(char*)malloc(20*sizeof(char));
              st[count].c_code[st[count].course_cnt]=(char*)malloc(10*sizeof(char));*/
            int num = search_st(token);
            if(num==-1)
            {
                strcpy(st[count].roll,token);
                strcpy(st[count].c_code[st[count].course_cnt],token1);
                strcpy(st[count].courses[st[count].course_cnt],token2);
                //printf("%s\t%s\t%s\n",st[count].roll,st[count].c_code[st[count].course_cnt],st[count].courses[st[count].course_cnt]);
                st[count].course_cnt++;
                if(st[count].course_cnt>20)
                {
                    printf("coursecount exceeded");
                    if(fp) fclose(fp);
                    return 0;
                }
                count++;
            }
            else
            {
                strcpy(st[num].c_code[st[num].course_cnt],token1);
                strcpy(st[num].courses[st[num].course_cnt],token2);
               // printf("%s\t%s\t%s\n",st[num].roll,st[num].c_code[st[num].course_cnt],st[num].courses[st[num].course_cnt]);
                st[num].course_cnt++;
                if(st[num].course_cnt>20)
                {
                    printf("coursecount exceeded");
                    if(fp) fclose(fp);
                    return 0;
                }
            }
        }
        else
        {
            int num = search_st(token);
            if(num==-1)
            {
                strcpy(st[count].roll,token);
                strcpy(st[count].c_code[st[count].course_cnt],token1);
                strcpy(st[count].courses[st[count].course_cnt],token2);
                //printf("%s\t%s\t%s\n",st[count].roll,st[count].c_code[st[count].course_cnt],st[count].courses[st[count].course_cnt]);
                st[count].course_cnt++;
                if(st[count].course_cnt>20)
                {
                    printf("coursecount exceeded");
                    if(fp) fclose(fp);
                    return 0;
                }
                count++;
            }
            else
            {
                strcpy(st[num].c_code[st[num].course_cnt],token1);
                strcpy(st[num].courses[st[num].course_cnt],token2);
                //printf("%s\t%s\t%s\n",st[num].roll,st[num].c_code[st[num].course_cnt],st[num].courses[st[num].course_cnt]);
                st[num].course_cnt++;
                if(st[num].course_cnt>20)
                {
                    printf("coursecount exceeded");
                    if(fp) fclose(fp);
                    return 0;
                }
            }
        
        }
    }
    
    if(fp) fclose(fp);
    return 1;
}
bool store_formated(const char* filename){
    FILE* fp =fopen(filename,"w+");
    int i,j;
    fprintf(fp,"Student Name\tCourse Number\tCourse Name\n");
    for(i=0;i<count;i++){
        j=0;
        fprintf(fp, "%s\t%s\t%s\n",st[i].roll,st[i].c_code[j],st[i].courses[j]);
        for(j=1;j<st[i].course_cnt;j++)
            fprintf(fp, "\t\t%s\t%s\n",st[i].c_code[j],st[i].courses[j]);
    }
    if(fp) fclose(fp);
    return true;
}
#endif