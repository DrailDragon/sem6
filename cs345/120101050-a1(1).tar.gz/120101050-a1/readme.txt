1.compile as gcc [-o asgn1] mainf.c
2.run as ./a.outor ./[asgn1] /path/to/database
3.files with 1 in names are used as intermediate results.
4.Logic is as follows:
	1.Read the directory database recursively.
	2.First Store the student info as department-wise(each dept has one file) 
		format: rollnumber1 course number1 course name1 //roll numbers are in each row
			rollnumber2 course number2 course name2
	3.Then again load the individual files'(dept's) student info and store as the format specified in the question,
	i.e. for each rollnumber1 
				course number1 course name1
				course number2 course name2 //for each rollnumber exaustive list of coursenumber and course name
Thank you.
			
[]=>optional
for query :+91 7896364534,pintu.kumar@iitg.ernet.in
