#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<error.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<stdio.h>
#include "stud_info.h"
char* search_name(char coursecd[])
{
    FILE* fp=fopen("/home/pintukumar/cs345/database/index.txt","r");
    if(fp==NULL)
    {
        printf("error opening index.txt\n");
        return NULL;
    }
    char read;
    char *line = NULL;
    size_t len = 0;
    while ((read = getline(&line,&len, fp)) != -1)
    {
        const char s[] =",";
        char* token = strtok(line,s);
        if(strcmp(token,coursecd)==0)
        {

            token=strtok(NULL,s);
            fclose(fp);
            return token;
        }

    }
	if(fp)
    fclose(fp);

    return NULL;
}
int read_dir(char *pth)
{
    char path[1000];
    strcpy(path,pth);
    DIR *dp;
    struct dirent *files;
    /*structure for storing inode numbers and files in dir
    struct dirent
    {
        ino_t d_ino;
        char d_name[NAME_MAX+1]
    }
    */
    if((dp=opendir(path))==NULL)
        perror("dir\n");
    char newp[1000];
    struct stat buf;
    while((files=readdir(dp))!=NULL)
    {
        if(!strcmp(files->d_name,".") || !strcmp(files->d_name,".."))
            continue;
        strcpy(newp,path);
        strcat(newp,"/");
        strcat(newp,files->d_name);
      //  printf("%s\n",newp);
        FILE* f1= fopen(newp,"r");

        /*extract course number*/
        const char s1[] =".";
        char* token1 = strtok(files->d_name,s1);/*token1 contains course code*/

        //printf("%s\n",token1);
        char read;
        char *line = NULL;
        size_t len = 0;
        FILE* f2;
        while ((read = getline(&line,&len, f1)) != -1)
        {
            const char s[] =",";
            char* token = strtok(line,s);
            //printf("%s\n",token);
            char x[2];
            x[0]=token[4];
            x[1]=token[5];
            //printf("%s\n",x );
            if(strcmp(x,"01")==0){
            	f2=fopen("cse1.txt","a+");
            	if(f2==NULL){
            		printf("error opening cse1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"02")==0){
            	f2=fopen("ece1.txt","a+");
            	if(f2==NULL){
            		printf("error opening ece.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"03")==0){
            	f2=fopen("me1.txt","a+");
            	if(f2==NULL){
            		printf("error opening me1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"04")==0){
            	f2=fopen("ce1.txt","a+");
            	if(f2==NULL){
            		printf("error opening ce1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"05")==0){
            	f2=fopen("dd1.txt","a+");
            	if(f2==NULL){
            		printf("error opening dd1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"06")==0){
            	f2=fopen("bt1.txt","a+");
            	if(f2==NULL){
            		printf("error opening bt1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"07")==0){
            	f2=fopen("cl1.txt","a+");
            	if(f2==NULL){
            		printf("error opening cl1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"08")==0){
            	f2=fopen("eee1.txt","a+");
            	if(f2==NULL){
            		printf("error opening eee1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"21")==0){
            	f2=fopen("ep1.txt","a+");
            	if(f2==NULL){
            		printf("error opening ep1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"22")==0){
            	f2=fopen("ct1.txt","a+");
            	if(f2==NULL){
            		printf("error opening ct1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"23")==0){
            	f2=fopen("mc1.txt","a+");
            	if(f2==NULL){
            		printf("error opening mc1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else if(strcmp(x,"41")==0){
            	f2=fopen("hs1.txt","a+");
            	if(f2==NULL){
            		printf("error opening hs1.txt\n");
            		continue;
            	}else{
            		fprintf(f2, "%s\t%s\t%s\n",token,token1,search_name(token1) );
            		fclose(f2);
            	}
            }else{
            	//printf("Invalid rollnumber extracted\n");
            	continue;
            }
		//if(line) line=NULL;
        }
        fclose(f1);
        //stat function return a structure of information about the file
        if(stat(newp,&buf)==-1)
            perror("stat");
        if(S_ISDIR(buf.st_mode))// if directory, then add a "/" to current path
        {

            strcat(path,"/");
            strcat(path,files->d_name);
            read_dir(path);
            strcpy(path,pth);
        }
    }
}
int main(int argc,char* argv[]){
	read_dir(argv[1]);
	int i;
	char dtmp[][10]={"cse1.txt","ece1.txt","me1.txt","ce1.txt","dd1.txt","bt1.txt","cl1.txt","eee1.txt","ep1.txt","ct1.txt","mc1.txt","hs1.txt"};
	char dept[][10]={"cse.txt","ece.txt","me.txt","ce.txt","dd.txt","bt.txt","cl.txt","eee.txt","ep.txt","ct.txt","mc.txt","hs.txt"};
	for(i=0;i<12;i++){
		load_stud_info(dtmp[i]);
		store_formated(dept[i]);
	}
	return 0;
}
